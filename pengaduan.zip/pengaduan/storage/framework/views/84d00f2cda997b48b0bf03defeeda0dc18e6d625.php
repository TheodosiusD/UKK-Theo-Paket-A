
<?php $__env->startSection('content'); ?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
        <a class="nav-link" href="<?php echo e(route('pengaduan.create')); ?>"> Tambah Pengaduan
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Tgl Pengaduan</th>
                        <th>NIK</th>
                        <th>Judul Laporan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php $__currentLoopData = $datapen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowpen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rowpen->tgl_pengaduan); ?></td>
                        <td><?php echo e($rowpen->nik); ?></td>
                        <td><?php echo e($rowpen->judul_laporan); ?></td>
                        <td><img src="<?php echo e(asset('storage/'.$rowpen->foto)); ?>" width="70px;"></td>
                        <td><?php echo e($rowpen->status); ?></td>
                        <td>
                            <?php if($rowpen->status === 'menunggu'): ?>      
                            <form action="<?php echo e(route('pengaduans.proses', $rowpen->id_pengaduan)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary">Proses</button>
                            </form>
                            <?php endif; ?>
                            
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
        </div>
    </div>
</div>
</main>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/pengaduans/index.blade.php ENDPATH**/ ?>