\<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="<?php echo e(asset('')); ?>assets/css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <form action="<?php echo e(route('petugas.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Tambah Petugas</h3></div>
                                    <div class="card-body">
                                        <form>
                                            <div class="row mb-3">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="id_petugas" type="text" placeholder="Input nama anda" />
                                                    <label style="margin-left:10px;" for="inputEmail">ID Petugas</label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="nama_petugas" type="text" placeholder="Input nama anda" />
                                                    <label style="margin-left:10px;" for="inputEmail">Nama Petugas</label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="username" type="text" placeholder="Input nama anda" />
                                                    <label style="margin-left:10px;" for="inputEmail">Input Username</label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="password" type="password" placeholder="Input nama anda" />
                                                    <label style="margin-left:10px;" for="inputEmail">Input Password</label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" name="telp" type="text" placeholder="Input nama anda" />
                                                    <label style="margin-left:10px;" for="inputEmail">Input No. Telp</label>
                                                </div>
                                                <input type="radio" id="html" name="role" value="petugas">
                                                <label for="html">Petugas</label><br>
                                                <input type="radio" id="html" name="role" value="admin">
                                                <label for="html">Admin</label><br>
                                            <div class="mt-4 mb-0">
                                                <input type="submit"> 
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </form>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/petugas/create.blade.php ENDPATH**/ ?>