
<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
        <a class="nav-link" href="<?php echo e(route('petugas.create')); ?>"> Tambah Petugas
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>ID Petugas</th>
                        <th>Nama Petugas</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>No. Telp</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $datape; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowpe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td><?php echo e($rowpe->id_petugas); ?></td>
                        <td><?php echo e($rowpe->nama_petugas); ?></td>
                        <td><?php echo e($rowpe->username); ?></td>
                        <td><?php echo e($rowpe->password); ?></td>
                        <td><?php echo e($rowpe->telp); ?></td>
                        <td><?php echo e($rowpe->role); ?></td>
                    </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
</main>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/petugas/index.blade.php ENDPATH**/ ?>