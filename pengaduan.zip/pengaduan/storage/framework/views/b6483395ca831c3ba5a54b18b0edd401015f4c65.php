
<?php $__env->startSection('content'); ?>

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
            <h1>s</h1>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>No. Telp</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $datama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <tr>
                        <td><?php echo e($rowma->nik); ?></td>
                        <td><?php echo e($rowma->nama); ?></td>
                        <td><?php echo e($rowma->username); ?></td>
                        <td><?php echo e($rowma->password); ?></td>
                        <td><?php echo e($rowma->telp); ?></td>
                        <td>
                            <a class="nav-link" href=" <?php echo e(route('masyarakat.edit', $rowma->id)); ?>"><button type="submit" class="btn btn-primary">Edit</button></a>
                            <form action="<?php echo e(route('masyarakat.destroy', $rowma->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
</main>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pengaduan\resources\views/masyarakat/index.blade.php ENDPATH**/ ?>