@extends('layout.master')
@section('content')

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
            <h1>s</h1>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>No. Telp</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                @foreach ($datama as $rowma)
                <tbody>
                    <tr>
                        <td>{{ $rowma->nik }}</td>
                        <td>{{ $rowma->nama }}</td>
                        <td>{{ $rowma->username }}</td>
                        <td>{{ $rowma->password }}</td>
                        <td>{{ $rowma->telp }}</td>
                        <td>
                            <a class="nav-link" href=" {{ route('masyarakat.edit', $rowma->id) }}"><button type="submit" class="btn btn-primary">Edit</button></a>
                            <form action="{{ route('masyarakat.destroy', $rowma->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                </tbody>
                @endforeach
            </table>
        </div>
    </div>
</div>
</main>
</div>


@endsection