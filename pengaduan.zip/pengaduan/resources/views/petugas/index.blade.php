@extends('layout.master')
@section('content')
<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
        <a class="nav-link" href="{{route('petugas.create')}}"> Tambah Petugas
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>ID Petugas</th>
                        <th>Nama Petugas</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>No. Telp</th>
                        <th>Role</th>
                    </tr>
                </thead>
                @foreach ($datape as $rowpe)
                <tbody>
                    <tr>
                        <td>{{ $rowpe->id_petugas }}</td>
                        <td>{{ $rowpe->nama_petugas }}</td>
                        <td>{{ $rowpe->username }}</td>
                        <td>{{ $rowpe->password }}</td>
                        <td>{{ $rowpe->telp }}</td>
                        <td>{{ $rowpe->role }}</td>
                    </tr>
                </tbody>
                @endforeach
            </table>
        </div>
    </div>
</div>
</main>
</div>


@endsection