@extends('layout.master')
@section('content')

<div id="layoutSidenav_content">
<main>
<div class="container-fluid px-4">
<ol class="breadcrumb mb-4"> 

</ol>

    <div class="card mb-4">
        <div class="card-header">
            <a class="nav-link" href="{{route('pengaduan.create')}}"> Tambah Pengaduan
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Tgl Pengaduan</th>
                        <th>NIK</th>
                        <th>Judul Laporan</th>
                        <th>Foto</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                
                <tbody>
                    @foreach ($datapen as $rowpen)
                    <tr>
                        <td>{{ $rowpen->tgl_pengaduan }}</td>
                        <td>{{ $rowpen->nik }}</td>
                        <td>{{ $rowpen->judul_laporan }}</td>
                        <td><img src="{{ asset('storage/'.$rowpen->foto) }}" width="70px;"></td>
                        <td>{{ $rowpen->status }}</td>
                        <td>

                             </td>
                        {{-- <td>
                            <a class="nav-link" href="#"><button type="submit" class="btn btn-primary">Edit</button></a>
                            <form action="#" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td> --}}
                    </tr>
                    @endforeach
                </tbody>
                
            </table>
        </div>
    </div>
</div>
</main>
</div>


@endsection